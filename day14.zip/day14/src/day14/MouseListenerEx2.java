package day14;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;

import javax.swing.*;

public class MouseListenerEx2 extends JFrame {
	
	JLabel lb;
	public MouseListenerEx2() {
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		lb = new JLabel("안녕하세요");
		lb.setLocation(30, 30);
		lb.setSize(50, 20);
		con.add(lb);
		
		con.addMouseListener(new MyMouseListener());
		
		setSize(400, 400);
		setVisible(true);
		setTitle(lb.getText());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new MouseListenerEx2();
	}
	
	//내부(이너) 클래스로 마우스 리스너 객체 구현
	class MyMouseListener extends MouseAdapter{
		
		

		@Override
		public void mousePressed(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			lb.setLocation(x, y);
			
		}
	}

}
