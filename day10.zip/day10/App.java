package day10;
import java.util.Random;
import java.util.Scanner;
abstract class Player {
	protected String shape[] = {"가위", "바위", "보"};
	private String name;
	public Player(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	abstract public String turn();
}
class MachinePlayer extends Player {
	public MachinePlayer(String name) {
		super(name);
	}
	@Override
	public String turn() {
		Random random = new Random();
		int num = random.nextInt(3);
		return shape[num];
	}
}
class HumanPlayer extends Player {
	public HumanPlayer(String name) {
		super(name);
	}
	@Override
	public String turn() {
		Scanner sc = new Scanner(System.in);
		System.out.println(super.getName() + "님, 무엇을 내시겠습니까?");
		String answer = sc.next();
		sc.close();
		return answer;
		
	}
	
}
public class App {

	public static void main(String[] args) {
		Player machine = new MachinePlayer("터미네이터");
		Player human = new HumanPlayer("황기태");
		String m = machine.turn();
		String h = human.turn();
		System.out.println(machine.getName() + " : " + m + " , " + human.getName() + " : " + h);
		if(h.equals(m)) {
			System.out.println(machine.getName() + " 승리!");
		} else {
			System.out.println(human.getName() + " 승리!");
		}
		

	}

}
