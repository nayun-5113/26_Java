package day11;
import java.util.Random;
public class Lotto {
	
	

	public static void main(String[] args) {
		//난수 1~45까지의 임의의 정수 6개 생성
		Random random = new Random();
		//int n[] = new int[6];
		
		int n;
		for(int i=1; i<=6; i++) {
			n = random.nextInt(45)+1;//=1~46 
			System.out.println(n);
		}

	}

}
