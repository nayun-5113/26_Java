package my.app;
import java.util.Vector;

class Point{
	private int x,y;
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}

public class PointVector {

	public static void main(String[] args) {
		Vector<Point> pvectors = new Vector<Point>();//vector 객체
		pvectors.add(new Point(3,5));//자료 저장 (원소(요소) 삽입)
		pvectors.add(new Point(30,70));
		
		for(int i=0; i<pvectors.size(); i++) {
			System.out.println("X: " + pvectors.elementAt(i).getX() + " Y: " + pvectors.elementAt(i).getY());//자료검색
			//System.out.println(pvectors.elementAt(i).getX());
		}
		for(Point p:pvectors) {
			System.out.println(p.getX());
			System.out.println(p.getY());
		}
	}
}
