package my.app;
import java.util.Scanner;
import java.util.ArrayList;

public class ArrayListEx {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<String> alist = new ArrayList<String>();
		for(int i=0; i<4;i++) { //이름 4번 입력해서 컬렉션에 저장
			System.out.println("이름을 입력하세요.");
			alist.add(scan.nextLine());
		}
		for(int i=0; i<alist.size();i++) {
			System.out.print(alist.get(i) + " ");
		}
		scan.close();
	}

}
