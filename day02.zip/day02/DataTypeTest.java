package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		//1. 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 22;
		height = 164.8;
		weight = 55;
		
		//2. 레퍼런스형 - 3개(배열, 클래스, 인터페이스)
		String name = "김나윤";
		String addr = "경기도 화성시 동탄역로 102";
		//name = "김나윤";
		//String s = new String("김나윤");
		
		
		//DataTypeTest dtt = new DataTypeTest();
		
		//3. 변수값 출력
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("이름:"+name);
		System.out.println("주소:"+addr);
	}

}
