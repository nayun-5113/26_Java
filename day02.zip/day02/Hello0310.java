package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("자바프로그래밍으로 만들고 싶은 것");
		System.out.print("웹페이지 만들어보기\n");
		System.out.println("AI 활용해서 뭐든 만들어보기");
		System.out.println("게임 만들어보기");

	}

}
